
package Model.WorkQueue;

/**
 *
 * @author Kunal
 */
public class YieldRequest extends WorkRequest{
    
    private String testingOutput;

    public String getTestingOutput() {
        return testingOutput;
    }

    public void setTestingOutput(String testingOutput) {
        this.testingOutput = testingOutput;
    }
    /*submit the inputs and wait the output

creates new panel for new role in the organization

data to be defined.

data passed in the function.

*/
    
}
